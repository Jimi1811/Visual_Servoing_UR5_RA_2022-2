#!/usr/bin/python

#
# Send joint values to UR5 using messages
#

import rospy
from sensor_msgs.msg import JointState

from markers import *
from functions import *

dis = 0.15

def main():

    rospy.init_node('send_joints')
    pub = rospy.Publisher('joint_states', JointState, queue_size=10)
    bmarker = BallMarker(color["RED"])    

    # Joint names
    jnames = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint','wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint','robotiq_85_left_knuckle_joint', 'robotiq_85_right_knuckle_joint', 'robotiq_85_left_inner_knuckle_joint',
            'robotiq_85_right_inner_knuckle_joint', 'robotiq_85_left_finger_tip_joint', 'robotiq_85_right_finger_tip_joint']
    # Joint Configuration
    q = [0.0, -pi/2, pi/2, 0.0, pi/2, 0.0]
    q_g = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    q_t = np.append(q,q_g)
    # End effector with respect to the base
    T = fkine_ur5(q,dis)
    bmarker.position(T)

    # Object (message) whose type is JointState
    jstate = JointState()
    # Set values to the message
    jstate.header.stamp = rospy.Time.now()
    jstate.name = jnames
    # Add the head joint value (with value 0) to the joints
    jstate.position = q_t
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        # Current time (needed for ROS)
        jstate.header.stamp = rospy.Time.now()
        # Publish the message
        pub.publish(jstate)
        bmarker.publish()
        # Wait for the next iteration
        rate.sleep()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        print ("Program interrupted before completion")
