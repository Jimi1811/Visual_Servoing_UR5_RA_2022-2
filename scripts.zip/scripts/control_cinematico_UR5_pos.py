#!/usr/bin/env python

from __future__ import print_function
from functions import *
from markers import *
import rospy
from sensor_msgs.msg import JointState
import numpy as np
pi = np.pi


def main():

    # Initialize the node
    rospy.init_node("testKineControlPosition")
    print('starting motion ... ')

    # Publisher: publish to the joint_states topic
    pub = rospy.Publisher('joint_states', JointState, queue_size=10)

    # Files for the logs
    fxcurrent = open("/tmp/xcurrent.txt", "w")
    fxdesired = open("/tmp/xdesired.txt", "w")
    fq = open("/tmp/q.txt", "w")

    # Markers for the current and desired positions
    bmarker_desired = BallMarker(color['GREEN'])

    # Joint names
    jnames = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint', 'robotiq_85_left_knuckle_joint', 'robotiq_85_right_knuckle_joint', 'robotiq_85_left_inner_knuckle_joint',
              'robotiq_85_right_inner_knuckle_joint', 'robotiq_85_left_finger_tip_joint', 'robotiq_85_right_finger_tip_joint']

    # Desired position
    xd = np.array([0.6, 0.5, 0.6])

    # Initial configuration
    q0 = np.array([0.0, -pi/2, pi/2, 0.0, pi/2, 0.0])
    q_g = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    q_t0 = np.append(q0, q_g)

    epsilon = 0.0001
    k = 0.7
    count = 0

    # Green marker shows the desired position
    bmarker_desired.xyz(xd)

    # Instance of the JointState message
    jstate = JointState()
    # Values of the message
    jstate.header.stamp = rospy.Time.now()
    jstate.name = jnames
    # Add the head joint value (with value 0) to the joints
    jstate.position = q_t0

    # Frequency (in Hz) and control period
    freq = 200
    dt = 1.0/freq
    rate = rospy.Rate(freq)

    # Initial joint configuration
    q = copy(q0)
    # Main loop
    while not rospy.is_shutdown():

        # Current time (needed for ROS)
        jstate.header.stamp = rospy.Time.now()
        # Kinematic control law for position
        # -----------------------------

        dis = 0.2

        J = jacobian_position(q, 0.0001,dis)
        x = fkine_ur5(q,dis)
        x = x[0:3, 3]

        e = x - xd

        if(np.linalg.norm(e) < epsilon):
            print('Desired point reached')
            print(x)
            # print(q)
            break

        de = -k*e
        dq = np.linalg.pinv(J).dot(de)
        q = q + dt*dq

        count = count + 1

        if(count > 100000):
            print('Max number of iterations reached')
            break

        # -----------------------------

        # Log values
        fxcurrent.write(str(x[0])+' '+str(x[1]) + ' '+str(x[2])+'\n')
        fxdesired.write(str(xd[0])+' '+str(xd[1])+' '+str(xd[2])+'\n')
        fq.write(str(q[0])+" "+str(q[1])+" "+str(q[2])+" "+str(q[3])+" " +
                 str(q[4])+" "+str(q[5])+"\n")

        # Publish the message
        q_t = np.append(q, q_g)
        jstate.position = q_t
        pub.publish(jstate)
        bmarker_desired.xyz(xd)
        rate.sleep()

    print('ending motion ...')
    print('error: ', e)
    fxcurrent.close()
    fxdesired.close()
    fq.close()


if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        print("Program interrupted before completion")
