#!/usr/bin/env python
#
 
from __future__ import print_function
import rospy
from sensor_msgs.msg import JointState
 
from pyquaternion import Quaternion
 
from markers import *
from functions import *

import numpy as np
pi = np.pi
 
def main():

    # Initialize the node
    rospy.init_node("testKineControlPose")
    print('starting motion ... ')

    # Publisher: publish to the joint_states topic
    pub = rospy.Publisher('joint_states', JointState, queue_size=1000)

    # Files for the logs
    fxcurrent = open("/tmp/xcurrent.txt", "w")
    fxdesired = open("/tmp/xdesired.txt", "w")

    frcurrent = open("/tmp/rcurrent.txt", "w")
    frdesired = open("/tmp/rdesired.txt", "w")

    fq = open("/tmp/q.txt", "w")

    # Markers for the current and desired positions
    bmarker_desired = BallMarker(color['GREEN'])

    # Joint names
    jnames = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint', 'robotiq_85_left_knuckle_joint', 'robotiq_85_right_knuckle_joint', 'robotiq_85_left_inner_knuckle_joint',
              'robotiq_85_right_inner_knuckle_joint', 'robotiq_85_left_finger_tip_joint', 'robotiq_85_right_finger_tip_joint']

    # Rotation desired
    Rd = np.array([[1,0,0],[0,1,0],[0,0,1]])
    tempq = Quaternion(matrix=Rd)
    qd = np.array([tempq.w, tempq.x, tempq.y, tempq.z])
    qd = rot2quat(Rd)
    
    # Find an xd that the robot can reach
    xd = np.array([0.5, 0.4, 0.5, qd[0], qd[1], qd[2], qd[3]])
    # Initial configuration
    q0  = np.array([0.0, -pi/2, pi/2, 0.0, pi/2, 0.0])
    q_g = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    q_t0 = np.append(q0, q_g)

    # Resulting initial pose (end effector with respect to the base link)
    dis = 0.15
    T = fkine_ur5(q0,dis)
    x0 = TF2xyzquat(T)
    
    epsilon = 0.000001
    k = 0.75
    count = 0
    
    # Markers for the current and the desired pose
    bmarker_desired.xyz(xd)
    
    # Instance of the JointState message
    jstate = JointState()
    # Values of the message
    jstate.header.stamp = rospy.Time.now()
    jstate.name = jnames
    # Add the head joint value (with value 0) to the joints
    jstate.position = q_t0
    
    # Frequency (in Hz) and control period 
    freq = 200
    dt = 1.0/freq
    rate = rospy.Rate(freq)
    
    # Initial joint configuration
    q = copy(q0)
    x = copy(x0)
    quat = x[3:7]
    # Initialize the derror vector (derivative of the error)
    derror = np.zeros(7)
    e = np.zeros(7)
    
    quat_wd = qd[0]
    quat_ed = qd[1:4]
    
    # Main loop
    #for i in range(1):
    while not rospy.is_shutdown():
        # Current time (needed for ROS)
        jstate.header.stamp = rospy.Time.now()
        # Kinematic control law for the pose (complete here)
        # --------------------------------------------------
        
        dis = 0.2
        J = jacobian_pose(q, 0.0001,dis)
    
        quat_w = x[3]
        quat_e = x[4:7]
    
        e[0:3] = x[0:3] - xd[0:3]
    
        # e[3] = quat_wd*quat_w + quat_ed.T.dot(quat_e)
    
        e[3] = quat_wd*quat_w + (quat_ed.T).dot(quat_e) - 1
        e[4:7] = -quat_wd*quat_e + quat_w*quat_ed - np.cross(quat_ed,quat_e)
    
        if(np.linalg.norm(e)-1 < epsilon):
            print('Desired pose reached')
            print('Quaternion:', quat)
            print('Rotation Matrix', Q_R(quat))
            print('TH final', fkine_ur5(q,dis))
            print('TH inicial', fkine_ur5(q0,dis))
            break
    
        """
    
        rankJ = matrix_rank(jacobian_pose(q))
        if (rankJ == 7):
            dq = np.linalg.pinv(J).dot(de)
        elif (rankJ < 7):
            dampedinvJ = J.T.dot(np.linalg.inv(J.dot(J.T) + 4*np.ones((7, 7))))
            dq = dampedinvJ.dot(de)
        
        """
        derror = -k*e
        dq = np.linalg.pinv(J).dot(derror)
        q = q + dt*dq
        
        count = count + 1
    
        print(np.linalg.norm(e))
    
        if(count > 10000):
            print('Max number of iterations reached')
            break
    
        # Current configuration transformation to current position
        T = fkine_ur5(q,dis)
        x = TF2xyzquat(T)
        Ro = T[0:3,0:3]
        euler = rot2euler(Ro)

        # -----------------------------

        # Log values
        fxcurrent.write(str(x[0])+' '+str(x[1]) + ' '+str(x[2])+'\n')
        fxdesired.write(str(xd[0])+' '+str(xd[1])+' '+str(xd[2])+'\n')

        frcurrent.write(str(euler[0,0])+' '+str(euler[0,1]) + ' '+str(euler[0,2])+'\n')
        fq.write(str(q[0])+" "+str(q[1])+" "+str(q[2])+" "+str(q[3])+" " +
                 str(q[4])+" "+str(q[5])+"\n")

        # Publish the message
        q_t = np.append(q, q_g)
        jstate.position = q_t

        pub.publish(jstate)
        bmarker_desired.xyz(xd)
        # Wait for the next iteration
        rate.sleep()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        print("Program interrupted before completion")
